clear all

format long
% Coded by Hyo-Sung Ahn, 2018, 3-15
% Inputs %%

% Input 1: define nodes
node_id =['1', '2', '3', '4', '5'];  

% Input 2:  decide the number of edges
NumofEdges = 5; 

% Input 3-1: decide the edges for sensings
for i=1:1:NumofEdges
    for j= 1:1:NumofEdges
        s_edge(i,j)=0;
        c_edge(i,j)=0;
    end
end


s_edge(1,2)=1; s_edge(1,3)=1; s_edge(1,4)=1; %Edge(2,3)=1; Edge(1,5)=1; 
s_m1=3;

%Edge(2,1)=1; Edge(2,4)=1;
s_edge(2,1)=1; s_edge(2,3)=1;  s_edge(2,4)=1;  s_edge(2,5)=1;
s_m2=4;

s_edge(3,1)=1; s_edge(3,2)=1; s_edge(3,4)=1; s_edge(3,5)=1;
s_m3=4;

s_edge(4,1)=1; s_edge(4,2)=1;  s_edge(4,3)=1; s_edge(4,5)=1;
s_m4=4;

%Edge(4,1)=1; %Edge(4,2)=0; Edge(4,5)=0;
%m4=2;

s_edge(5,2)=1; s_edge(5,4)=1 ; s_edge(5,3)=1 ;
s_m5=3;


% Input 3-2: decide the edges for communications/actuation --- actuation
% <--> communciation
c_edge(1,2)=1; c_edge(1,3)=1; c_edge(1,4)=1;  %Edge(2,3)=1; Edge(1,5)=1; 
c_m1=3;

%Edge(2,1)=1; Edge(2,4)=1;
c_edge(2,3)=1; c_edge(2,4)=1;   c_edge(2,5)=1; %s_edge(2,4)=1;
c_m2=3;


c_edge(3,4)=1; c_edge(3,5)=1; %s_edge(3,5)=1;
c_m3=2;


c_edge(4,5)=1; %c_edge(4,5)=1; %s_edge(4,5)=1;
c_m4=1;


%Edge(4,1)=1; %Edge(4,2)=0; Edge(4,5)=0;
%m4=2;

%c_edge(5,4)=1; c_edge(5,1)=1 ; %Edge(5,4)=1 ;
c_m5=0;







% Input 4: default values for initial states/ reference positions
systemsize= size(node_id);
NumofNodes = systemsize(2) ;

% case 1 == very general 
% phi(1)=pi/2.4; 
% phi(2)=1.5*pi;
% phi(3)=-1.3*pi;
% phi(4)=pi/5;
% phi(5)=-pi/8;
% 
% theta(1)=pi/1.9;
% theta(2)=-pi/3;
% theta(3)=-pi/3;
% theta(4)=pi/2.1;
% theta(5)=1.9*pi;
% 
% psi(1)=1.8*pi;
% psi(2)=-1.2*pi;
% psi(3)=1.2*pi;
% psi(4)=0.4*pi;
% psi(5)=-0.8*pi;

% case 2 --- liminted 0 < angles < \pi/2

phi(1)=pi/2.4; 
phi(2)=pi/4;
phi(3)=pi/3;
phi(4)=pi/2.8;
phi(5)=pi/8;

theta(1)=pi/10;
theta(2)= pi/5;
theta(3)= pi/4;
theta(4)= pi/6;
theta(5)= pi/7;

psi(1)=pi/5;
psi(2)= pi/9;
psi(3)= pi/20;
psi(4)= pi/3;
psi(5)= pi/2.1;



ini_pos(:,1) = [0, 0, 0]';
ini_pos(:,2) = [1, 3, 4]';
ini_pos(:,3) = [6, 7, -10]';
ini_pos(:,4) = [3, 0, -3]';
ini_pos(:,5) = [-3, -2, 1]';

ref_pos(:,1) = [0, 0, 0]';
ref_pos(:,2) = [2.4, 3.7, 4.2]';
ref_pos(:,3) = [2.2, -1.0, -3]';
ref_pos(:,4) = [-0.5, 3.3, -3]';
ref_pos(:,5) = [1.2, 1.3, -4.5]';



scaling = 1;
k_scaling_12 = 1;

ini_bar_d12 = norm(ini_pos(:,2) - ini_pos(:,1))^2;


time_index =1;
for i=1: NumofNodes
    D_phi = [cos(phi(i)), -sin(phi(i)), 0; sin(phi(i)), cos(phi(i)), 0; 0, 0, 1]  ;
    D_theta = [cos(theta(i)), 0, sin(theta(i)); 0, 1, 0; -sin(theta(i)),0,  cos(theta(i))];  
    D_psi = [1, 0, 0; 0, cos(psi(i)), -sin(psi(i)); 0, sin(psi(i)), cos(psi(i))] ;
    D_phi_theta_psi(:,:) = D_psi*D_theta*D_phi;    
    R(:,:, i, time_index) = D_phi_theta_psi ; % in R - 1st, 2nd --> rotation values; "i" --> agent index, 'time_index' --> sampling     
    pos(:,i,time_index) = ini_pos(:,i);    % 1st --> position, 2nd --> agent index, 'time index' --> sampling 
    %save_R(:,:,i, 1) = D_phi_theta_psi;
    %save_pos(:,i, 1) = ini_pos(:,i) ;
end


for ii=1:NumofNodes
%    for kk=1:2
%           rand_3_1 = rand(3,1);
%           rand_3_2 = rand(3,1);
           if ii==1
           rand_3_1 = [0.5, 0.3, 0.7]';
           rand_3_2 = [0.25, 0.6, 0.5]';           
           end
           
           if ii==2
           rand_3_1 = [0.65, 0.23, 0.17]';
           rand_3_2 = [0.35, 0.76, 0.95]';           
           end

           if ii==3
           rand_3_1 = [0.85, 0.32, 0.17]';
           rand_3_2 = [0.85, 0.56, 0.65]';           
           end

           if ii==4
           rand_3_1 = [0.25, 0.6, 0.27]';
           rand_3_2 = [0.55, 0.26, 0.95]';           
           end
           
           if ii==5
           rand_3_1 = [0.25, 0.93, 0.27]';
           rand_3_2 = [0.95, 0.16, 0.15]';           
           end

           rand_inputs(:,:) = [rand_3_1/norm(rand_3_1), rand_3_2/norm(rand_3_2)];
           z_hat(:,:, ii) = rand_inputs(:,:); %1st --> k=1, 2nd --> k=2; ii --> agent index
 %   end
end



%%%% Iteration loop starts %%%%

repeat_end = 100000;
dt = 0.005;
save_kk=0;
save_kkk=0;
save_interval =10;



for time_index=1: 1: repeat_end % time index
edge_distance_update = 0;
bearing_errors_update = 0;
% Agent updates
% 1. Update by sensings; R_{ji}^{-1}/ Omega_i
    for i=1: 1: NumofNodes
        for j=1:1: NumofNodes        
            if s_edge(j,i) ~= 1
                
            else
                
              inv_Ri =  R(:,:, i, time_index)';               
              R_ji_cal(:,:) = R(:,:, j, time_index)* inv_Ri ; 
              
              if time_index ==1
                eig(R_ji_cal);
              end
              
              inv_Rji = R_ji_cal(:,:)' ;
              R_ji_inv_cal(:,:) = inv_Rji;
              R_ji_inv(:,:, j, i) = R_ji_inv_cal(:,:) ; 
            end
        end
        
    % B_i
    
        v_i_1 = z_hat(:,1, i);
        b_i_1 = v_i_1/norm(v_i_1);        
        v_i_2 = z_hat(:,2, i) -     (z_hat(:,2, i)'*b_i_1) *b_i_1 ;
        b_i_2 = v_i_2/norm(v_i_2);  
        b_i_3 = cross(b_i_1, b_i_2);
        B_i(:,1, i) = b_i_1;
        B_i(:,2, i) = b_i_2;
        B_i(:,3, i) = b_i_3; 
        
        BBB=[b_i_1, b_i_2, b_i_3];
        %Omega_log = - log(BBB);
        
        trace_BBB  = trace(BBB);
        cri_trace = abs( 3- trace_BBB );
        
        if cri_trace <=0.000001
        Omega_log = -0.5*(BBB' - BBB);
        Omega(:,1,i) = Omega_log(:,1);
        Omega(:,2,i) = Omega_log(:,2);
        Omega(:,3,i) = Omega_log(:,3);               
        else
        vtheta_i = acos( (trace(BBB) -1)/2 );
        Omega_log = -vtheta_i/(2*sin(vtheta_i))*(BBB' - BBB);
        Omega(:,1,i) = Omega_log(:,1);
        Omega(:,2,i) = Omega_log(:,2);
        Omega(:,3,i) = Omega_log(:,3);   
        end
        
        %save_vtheta_i(i, time_index) =  vtheta_i;
    end 
    
    
  
    % updates of auxiliary variables/ rotation matrix R_i/ Omega_i/ position of agent i 
    for i=1: 1: NumofNodes   
        z_hat_k1_i_input_plus = 0;
        z_hat_k2_i_input_plus = 0;
        u_global_i_plus = zeros(3,1);
        
        %number_of_comm_neighbors = 0;
        nocn_i = 0;
        z_hat_i_12(:,:) = z_hat(:,:, i) ;    
        aji =1;

        for j=1: 1: NumofNodes                           
               if c_edge(j,i) == 1  % j is the incoming neighbor node of agent i               
               nocn_i = nocn_i +1;
               % z_hat    
               z_hat_j_12(:,:) = z_hat(:,:, j) ;
               
               z_hat_k1_i_input_plus = z_hat_k1_i_input_plus + aji*(R_ji_inv(:,:, j, i)* z_hat_j_12(:,1)  - z_hat_i_12(:,1) );               
               z_hat_k2_i_input_plus = z_hat_k2_i_input_plus + aji*(R_ji_inv(:,:, j, i)* z_hat_j_12(:,2)  - z_hat_i_12(:,2) );               
               
               % u_global_i update
               R_i_time(:,:) =  R(:,:, i, time_index);
               B_i_time(:,:) =  B_i(:,:, i);
               
               
               %%%%%%%%%% desired bearing vectors %%%%%%%%%%%%%%
               g_ji_ref(:,j,i) = (ref_pos(:,j) - ref_pos(:,i))/(norm(ref_pos(:,j) - ref_pos(:,i)));   
               g_ji_ref_local(:,j,i) = R(:,:, i, time_index)*g_ji_ref(:,j,i);                             
               g_ji(:,j,i) = (pos(:,j,time_index) - pos(:,i,time_index))/(norm( pos(:,j,time_index) - pos(:,i,time_index) ) );
               
               edge_distance_update = edge_distance_update   + norm(pos(:,j,time_index) - pos(:,i,time_index) ) ;               
               bearing_errors_update =  bearing_errors_update + norm( g_ji_ref(:,j,i) -  g_ji(:,j,i) );
               
               g_ji_vector_local(:,1) = R(:,:, i, time_index)*g_ji(:,j,i);               
               P_gji_local  = eye(3) - g_ji_vector_local* g_ji_vector_local'/(norm(g_ji_vector_local)*norm(g_ji_vector_local)) ;
               %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
               
               
               u_global_i_plus = u_global_i_plus - P_gji_local*g_ji_ref_local(:,j,i) ;               
               %u_global_i_plus = u_global_i_plus  +  ( pos(:,j,time_index) - pos(:,i,time_index) )  -   inv(R_i_time)*B_i_time* ( ref_pos(:,j) -   ref_pos(:,i) ) ;               
               
               else
                   %z_hat_k1_i_input_plus =0 ;
                   %z_hat_k2_i_input_plus =0 ;
                   
               end
               
               
        end             
              if i ==1                   
                bar_d12_t = norm(  pos(:,1,time_index) - pos(:,2,time_index) )^2 ;
                u_global_i_plus = -k_scaling_12*( bar_d12_t -scaling^2*ini_bar_d12 )*( pos(:,1,time_index) - pos(:,2,time_index) ) ;
              end
        
%        if nocn_i ~=0  % if there is neighbor agents            
               z_hat_dot_k1= z_hat_k1_i_input_plus - Omega(:,:,i)*z_hat_i_12(:,1);
               z_hat_dot_k2= z_hat_k2_i_input_plus - Omega(:,:,i)*z_hat_i_12(:,2);
               
               % update of auxiliary variables 
               z_hat_i_at_current(:,:) = z_hat(:,:, i) ;
               z_hat_propagation_k1 = z_hat_i_at_current(:,1) + z_hat_dot_k1*dt;
               z_hat_propagation_k2 = z_hat_i_at_current(:,2) + z_hat_dot_k2*dt;               
               
               z_hat(:,1, i) = z_hat_propagation_k1(:) ;
               z_hat(:,2, i) = z_hat_propagation_k2(:) ;               
               
               % update of rotation matrices                
               dot_R(:,:) = -Omega(:,:,i)*R(:,:, i, time_index) ;               
               R(:,:, i, time_index+1) = R(:,:, i, time_index) + dot_R(:,:)*dt;   
               
               % update of positions
               if i ==1                   
                 pos(:,i,time_index+1)  = pos(:,i,time_index)  +   u_global_i_plus*dt ; %% back to global
               else                   
                 pos(:,i,time_index+1)  = pos(:,i,time_index)  +   R(:,:, i, time_index)'*u_global_i_plus*dt ; %% back to global
               end
%               pos(:,i,time_index+1) =  pos(:,i,time_index)  + u_global_i_plus*dt;                            
%               ref_pos(:,1) = pos(:,1,time_index+1) ;
               
 %      else
 %             R(:,:, i, time_index+1) = R(:,:, i, time_index);   
 %             pos(:,i,time_index+1) =  pos(:,i,time_index);             
 %      end           
        
        
%         if nocn_i ~=0  % if there is neighbor agents            
%                z_hat_dot_k1= z_hat_k1_i_input_plus - Omega(:,:,i)*z_hat_i_12(:,1);
%                z_hat_dot_k2= z_hat_k2_i_input_plus - Omega(:,:,i)*z_hat_i_12(:,2);
%                
%                % update of auxiliary variables 
%                z_hat_i_at_current(:,:) = z_hat(:,:, i) ;
%                z_hat_propagation_k1 = z_hat_i_at_current(:,1) + z_hat_dot_k1*dt;
%                z_hat_propagation_k2 = z_hat_i_at_current(:,2) + z_hat_dot_k2*dt;               
%                
%                z_hat(:,1, i) = z_hat_propagation_k1(:) ;
%                z_hat(:,2, i) = z_hat_propagation_k2(:) ;               
%                
%                % update of rotation matrices                
%                dot_R(:,:) = -Omega(:,:,i)*R(:,:, i, time_index) ;               
%                R(:,:, i, time_index+1) = R(:,:, i, time_index) + dot_R(:,:)*dt;   
%                
%                % update of positions
%                pos(:,i,time_index+1)  = pos(:,i,time_index)  +   R(:,:, i, time_index)'*u_global_i_plus*dt ; %% back to global
% %               pos(:,i,time_index+1) =  pos(:,i,time_index)  + u_global_i_plus*dt;                            
%                
%        else
%               R(:,:, i, time_index+1) = R(:,:, i, time_index);   
%               pos(:,i,time_index+1) =  pos(:,i,time_index);             
%        end           


        
        save_index = mod(time_index, save_interval);    

        if  save_index ==1
            save_kk = save_kk+1;
            
%            save_bearing_errors(save_kk) = bearing_errors(time_index);
%            save_edge_distance(save_kk) = edge_distance(time_index);
%            save_time_index(save_kk) = save_kk;
            
            for i=1:1:NumofNodes
             save_R(:,:,i, save_kk) = R(:,:, i, time_index);
             Rotation_i(:,:) = save_R(:,:,i, save_kk);
             save_Euler_i = rotm2eul(Rotation_i);
             save_euler(:,i,save_kk) = save_Euler_i(:);
             save_pos(:,i, save_kk) = pos(:, i, time_index);    
             
             % compensation the rotation;             
             %c_save_pos(:,i, save_kk) =inv(R(:,:, i, time_index))*pos(:, i, time_index);  
             
            end
        end
    end
     save_index = mod(time_index, save_interval);  
            if  save_index ==1
            save_kkk = save_kkk+1;
             save_edge_distance(save_kkk) = edge_distance_update;
             save_bearing_errors(save_kkk) = bearing_errors_update; 
             save_time_index(save_kkk) = save_kkk;
            end

end


R(:,:, 1, time_index) 
R(:,:, 2, time_index)
R(:,:, 3, time_index) 
R(:,:, 4, time_index)
R(:,:, 5, time_index) 


  
  

%figure(1) ; hold on ; grid on;
ini_pos_1_x = ini_pos(1,1);
ini_pos_1_y = ini_pos(2,1);
ini_pos_1_z = ini_pos(3,1);
ini_pos_2_x = ini_pos(1,2);
ini_pos_2_y = ini_pos(2,2);
ini_pos_2_z = ini_pos(3,2);
ini_pos_3_x = ini_pos(1,3);
ini_pos_3_y = ini_pos(2,3);
ini_pos_3_z = ini_pos(3,3);
ini_pos_4_x = ini_pos(1,4);
ini_pos_4_y = ini_pos(2,4);
ini_pos_4_z = ini_pos(3,4);
ini_pos_5_x = ini_pos(1,5);
ini_pos_5_y = ini_pos(2,5);
ini_pos_5_z = ini_pos(3,5);


%ref_pos(:,1)
ref_pos_1_x = ref_pos(1,1);
ref_pos_1_y = ref_pos(2,1);
ref_pos_1_z = ref_pos(3,1);
ref_pos_2_x = ref_pos(1,2);
ref_pos_2_y = ref_pos(2,2);
ref_pos_2_z = ref_pos(3,2);
ref_pos_3_x = ref_pos(1,3);
ref_pos_3_y = ref_pos(2,3);
ref_pos_3_z = ref_pos(3,3);
ref_pos_4_x = ref_pos(1,4);
ref_pos_4_y = ref_pos(2,4);
ref_pos_4_z = ref_pos(3,4);
ref_pos_5_x = ref_pos(1,5);
ref_pos_5_y = ref_pos(2,5);
ref_pos_5_z = ref_pos(3,5);

pos_agent1_x(:) = save_pos(1,1,:);
pos_agent1_y(:) = save_pos(2,1,:);
pos_agent1_z(:) = save_pos(3,1,:);

pos_agent2_x(:) = save_pos(1,2,:);
pos_agent2_y(:) = save_pos(2,2,:);
pos_agent2_z(:) = save_pos(3,2,:);

pos_agent3_x(:) = save_pos(1,3,:);
pos_agent3_y(:) = save_pos(2,3,:);
pos_agent3_z(:) = save_pos(3,3,:);

pos_agent4_x(:) = save_pos(1,4,:);
pos_agent4_y(:) = save_pos(2,4,:);
pos_agent4_z(:) = save_pos(3,4,:);

pos_agent5_x(:) = save_pos(1,5,:);
pos_agent5_y(:) = save_pos(2,5,:);
pos_agent5_z(:) = save_pos(3,5,:);





% c_pos_agent1_x(:) = c_save_pos(1,1,:);
% c_pos_agent1_y(:) = c_save_pos(2,1,:);
% c_pos_agent1_z(:) = c_save_pos(3,1,:);
% 
% c_pos_agent2_x(:) = c_save_pos(1,2,:);
% c_pos_agent2_y(:) = c_save_pos(2,2,:);
% c_pos_agent2_z(:) = c_save_pos(3,2,:);
% 
% c_pos_agent3_x(:) = c_save_pos(1,3,:);
% c_pos_agent3_y(:) = c_save_pos(2,3,:);
% c_pos_agent3_z(:) = c_save_pos(3,3,:);
% 
% c_pos_agent4_x(:) = c_save_pos(1,4,:);
% c_pos_agent4_y(:) = c_save_pos(2,4,:);
% c_pos_agent4_z(:) = c_save_pos(3,4,:);
% 
% c_pos_agent5_x(:) = c_save_pos(1,5,:);
% c_pos_agent5_y(:) = c_save_pos(2,5,:);
% c_pos_agent5_z(:) = c_save_pos(3,5,:);
% 


figure(1); grid on;

plot3(pos_agent1_x, pos_agent1_y, pos_agent1_z,'b-','LineWidth',2); hold on;grid on;
plot3(pos_agent2_x, pos_agent2_y, pos_agent2_z,'r-','LineWidth',2); hold on;grid on;
plot3(pos_agent3_x, pos_agent3_y, pos_agent3_z,'k-','LineWidth',2); hold on;grid on;
plot3(pos_agent4_x, pos_agent4_y, pos_agent4_z,'c-','LineWidth',2); hold on;grid on;
plot3(pos_agent5_x, pos_agent5_y, pos_agent5_z,'g-','LineWidth',2); hold on;grid on;
%legend('p_1(t)', 'p_2(t)', 'p_3(t)', 'p_4(t)', 'p_5(t)'); hold on;


plot3(ini_pos_1_x, ini_pos_1_y, ini_pos_1_z, 'bo','LineWidth',2); hold on;grid on;
plot3(ini_pos_2_x, ini_pos_2_y, ini_pos_2_z, 'ro','LineWidth',2); hold on;grid on;
plot3(ini_pos_3_x, ini_pos_3_y, ini_pos_3_z, 'ko','LineWidth',2); hold on;grid on;
plot3(ini_pos_4_x, ini_pos_4_y, ini_pos_4_z, 'co','LineWidth',2); hold on;grid on;
plot3(ini_pos_5_x, ini_pos_5_y, ini_pos_5_z, 'go','LineWidth',2); hold on;grid on;
%legend('p_1(t_0)', 'p_2(t_0)', 'p_3(t_0)', 'p_4(t_0)', 'p_5(t_0)'); hold on;



plot3(ref_pos_1_x, ref_pos_1_y, ref_pos_1_z, 'b>','LineWidth',2); hold on;grid on;
plot3(ref_pos_2_x, ref_pos_2_y, ref_pos_2_z, 'r>','LineWidth',2); hold on;grid on;
plot3(ref_pos_3_x, ref_pos_3_y, ref_pos_3_z, 'k>','LineWidth',2); hold on;grid on;
plot3(ref_pos_4_x, ref_pos_4_y, ref_pos_4_z, 'c>','LineWidth',2); hold on;grid on;
plot3(ref_pos_5_x, ref_pos_5_y, ref_pos_5_z, 'g>','LineWidth',2); hold on;grid on;
%legend('p_1(t)', 'p_2(t)', 'p_3(t)', 'p_4(t)', 'p_5(t)', 'p_1(t_0)', 'p_2(t_0)', 'p_3(t_0)', 'p_4(t_0)', 'p_5(t_0)','p_1^\ast', 'p_2^\ast', 'p_3^\ast', 'p_4^\ast', 'p_5^\ast'); hold on;
%title('Before the offset compensation')
xlabel('x-axis');
ylabel('y-axis');
zlabel('z-axis');

%%%%%%%%%% compensation %%%%%%%%%%%

agent1_final(:,1) = save_pos(:,1,save_kk);
agent2_final(:,1) = save_pos(:,2,save_kk);
agent3_final(:,1) = save_pos(:,3,save_kk);
agent4_final(:,1) = save_pos(:,4,save_kk);
agent5_final(:,1) = save_pos(:,5,save_kk);

com_ref1(:,1) = inv( save_R(:,:, 1, save_kk))*ref_pos(:,1) ;
com_ref2(:,1) = inv( save_R(:,:, 2, save_kk))*ref_pos(:,2) ;
com_ref3(:,1) = inv( save_R(:,:, 3, save_kk))*ref_pos(:,3) ;
com_ref4(:,1) = inv( save_R(:,:, 4, save_kk))*ref_pos(:,4) ;
com_ref5(:,1) = inv( save_R(:,:, 5, save_kk))*ref_pos(:,5) ;

position_offset1 = agent1_final(:,1) - com_ref1(:,1);
position_offset2 = agent2_final(:,1) - com_ref2(:,1);
position_offset3 = agent3_final(:,1) - com_ref3(:,1);
position_offset4 = agent4_final(:,1) - com_ref4(:,1);
position_offset5 = agent5_final(:,1) - com_ref5(:,1);

com_com_ref1(:,1) = com_ref1(:,1) +position_offset1;
com_com_ref2(:,1) = com_ref2(:,1) +position_offset2;
com_com_ref3(:,1) = com_ref3(:,1) +position_offset3;
com_com_ref4(:,1) = com_ref4(:,1) +position_offset4;
com_com_ref5(:,1) = com_ref5(:,1) +position_offset5;



%     agent2_final(:,1) - agent4_final(:,1)
%     agent1_final(:,1) - agent5_final(:,1)
%     
%     com_ref2(:,1) - com_ref4(:,1)
%     com_ref1(:,1) - com_ref5(:,1) 
    
    
    





figure(2); grid on;

plot3(pos_agent1_x, pos_agent1_y, pos_agent1_z,'b-','LineWidth',2); hold on;grid on;
plot3(pos_agent2_x, pos_agent2_y, pos_agent2_z,'r-','LineWidth',2); hold on;grid on;
plot3(pos_agent3_x, pos_agent3_y, pos_agent3_z,'k-','LineWidth',2); hold on;grid on;
plot3(pos_agent4_x, pos_agent4_y, pos_agent4_z,'c-','LineWidth',2); hold on;grid on;
plot3(pos_agent5_x, pos_agent5_y, pos_agent5_z,'g-','LineWidth',2); hold on;grid on;
%legend('p_1(t)', 'p_2(t)', 'p_3(t)', 'p_4(t)', 'p_5(t)'); hold on;


plot3(ini_pos_1_x, ini_pos_1_y, ini_pos_1_z, 'bo','LineWidth',2); hold on;grid on;
plot3(ini_pos_2_x, ini_pos_2_y, ini_pos_2_z, 'ro','LineWidth',2); hold on;grid on;
plot3(ini_pos_3_x, ini_pos_3_y, ini_pos_3_z, 'ko','LineWidth',2); hold on;grid on;
plot3(ini_pos_4_x, ini_pos_4_y, ini_pos_4_z, 'co','LineWidth',2); hold on;grid on;
plot3(ini_pos_5_x, ini_pos_5_y, ini_pos_5_z, 'go','LineWidth',2); hold on;grid on;
%legend('p_1(t_0)', 'p_2(t_0)', 'p_3(t_0)', 'p_4(t_0)', 'p_5(t_0)'); hold on;



plot3(com_com_ref1(1,1), com_com_ref1(2,1), com_com_ref1(3,1), 'b>','LineWidth',2); hold on;grid on;
plot3(com_com_ref2(1,1), com_com_ref2(2,1), com_com_ref2(3,1), 'r>','LineWidth',2); hold on;grid on;
plot3(com_com_ref3(1,1), com_com_ref3(2,1), com_com_ref3(3,1), 'k>','LineWidth',2); hold on;grid on;
plot3(com_com_ref4(1,1), com_com_ref4(2,1), com_com_ref4(3,1), 'c>','LineWidth',2); hold on;grid on;
plot3(com_com_ref5(1,1), com_com_ref5(2,1), com_com_ref5(3,1), 'g>','LineWidth',2); hold on;grid on;
%legend('p_1(t)', 'p_2(t)', 'p_3(t)', 'p_4(t)', 'p_5(t)', 'p_1(t_0)', 'p_2(t_0)', 'p_3(t_0)', 'p_4(t_0)', 'p_5(t_0)','p_1^\ast', 'p_2^\ast', 'p_3^\ast', 'p_4^\ast', 'p_5^\ast'); hold on;
%title('After the offset compensation')
xlabel('x-axis');
ylabel('y-axis');
zlabel('z-axis');

% Euler angles

euler_agent1_x(:) = save_euler(1,1,:);
euler_agent1_y(:) = save_euler(2,1,:);
euler_agent1_z(:) = save_euler(3,1,:);

euler_agent2_x(:) = save_euler(1,2,:);
euler_agent2_y(:) = save_euler(2,2,:);
euler_agent2_z(:) = save_euler(3,2,:);

euler_agent3_x(:) = save_euler(1,3,:);
euler_agent3_y(:) = save_euler(2,3,:);
euler_agent3_z(:) = save_euler(3,3,:);

euler_agent4_x(:) = save_euler(1,4,:);
euler_agent4_y(:) = save_euler(2,4,:);
euler_agent4_z(:) = save_euler(3,4,:);

euler_agent5_x(:) = save_euler(1,5,:);
euler_agent5_y(:) = save_euler(2,5,:);
euler_agent5_z(:) = save_euler(3,5,:);



figure(3)




plot3(euler_agent1_x, euler_agent1_y, euler_agent1_z,'b-','LineWidth',2); hold on;grid on;
plot3(euler_agent2_x, euler_agent2_y, euler_agent2_z,'r-','LineWidth',2); hold on;grid on;
plot3(euler_agent3_x, euler_agent3_y, euler_agent3_z,'k-','LineWidth',2); hold on;grid on;
plot3(euler_agent4_x, euler_agent4_y, euler_agent4_z,'c-','LineWidth',2); hold on;grid on;
plot3(euler_agent5_x, euler_agent5_y, euler_agent5_z,'g-','LineWidth',2); hold on;grid on;

plot3(euler_agent1_x(1), euler_agent1_y(1), euler_agent1_z(1), 'bo','LineWidth',2); hold on;grid on;
plot3(euler_agent2_x(1), euler_agent2_y(1), euler_agent2_z(1), 'ro','LineWidth',2); hold on;grid on;
plot3(euler_agent3_x(1), euler_agent3_y(1), euler_agent3_z(1), 'ko','LineWidth',2); hold on;grid on;
plot3(euler_agent4_x(1), euler_agent4_y(1), euler_agent4_z(1), 'co','LineWidth',2); hold on;grid on;
plot3(euler_agent5_x(1), euler_agent5_y(1), euler_agent5_z(1), 'go','LineWidth',2); hold on;grid on;

plot3(euler_agent1_x(save_kk), euler_agent1_y(save_kk), euler_agent1_z(save_kk), 'b>','LineWidth',2); hold on;grid on;
plot3(euler_agent2_x(save_kk), euler_agent2_y(save_kk), euler_agent2_z(save_kk), 'r>','LineWidth',2); hold on;grid on;
plot3(euler_agent3_x(save_kk), euler_agent3_y(save_kk), euler_agent3_z(save_kk), 'k>','LineWidth',2); hold on;grid on;
plot3(euler_agent4_x(save_kk), euler_agent4_y(save_kk), euler_agent4_z(save_kk), 'c>','LineWidth',2); hold on;grid on;
plot3(euler_agent5_x(save_kk), euler_agent5_y(save_kk), euler_agent5_z(save_kk), 'g>','LineWidth',2); hold on;grid on;
%title('Orientation alignment (trajectories of Euler angles)')
xlabel('\phi(t)');
ylabel('\theta(t)');
zlabel('\psi(t)');
%legend('p_1(t_0)', 'p_2(t_0)', 'p_3(t_0)', 'p_4(t_0)', 'p_5(t_0)'); hold on;



figure(4)
plot(save_time_index, save_edge_distance,'LineWidth',2); hold on; grid on;

figure(5)
semilogy(save_time_index, save_bearing_errors,'LineWidth',2); hold on;  grid on;




% 
%     
% 
% figure(2); grid on;
% plot3(agent1_final(1,1), agent1_final(2,1), agent1_final(3,1), 'b>'); hold on;grid on;
% plot3(agent2_final(1,1), agent2_final(2,1), agent2_final(3,1), 'r>'); hold on;grid on;
% plot3(agent3_final(1,1), agent3_final(2,1), agent3_final(3,1), 'k>'); hold on;grid on;
% plot3(agent4_final(1,1), agent4_final(2,1), agent4_final(3,1), 'c>'); hold on;grid on;
% plot3(agent5_final(1,1), agent5_final(2,1), agent5_final(3,1), 'g>'); hold on;grid on;
% 
% plot3(com_ref1(1,1), com_ref1(2,1), com_ref1(3,1), 'bo'); hold on;grid on;
% plot3(com_ref2(1,1), com_ref2(2,1), com_ref2(3,1), 'ro'); hold on;grid on;
% plot3(com_ref3(1,1), com_ref3(2,1), com_ref3(3,1), 'ko'); hold on;grid on;
% plot3(com_ref4(1,1), com_ref4(2,1), com_ref4(3,1), 'co'); hold on;grid on;
% plot3(com_ref5(1,1), com_ref5(2,1), com_ref5(3,1), 'go'); hold on;grid on;
% 
% plot3(com_com_ref1(1,1), com_com_ref1(2,1), com_com_ref1(3,1), 'bx'); hold on;grid on;
% plot3(com_com_ref2(1,1), com_com_ref2(2,1), com_com_ref2(3,1), 'rx'); hold on;grid on;
% plot3(com_com_ref3(1,1), com_com_ref3(2,1), com_com_ref3(3,1), 'kx'); hold on;grid on;
% plot3(com_com_ref4(1,1), com_com_ref4(2,1), com_com_ref4(3,1), 'cx'); hold on;grid on;
% plot3(com_com_ref5(1,1), com_com_ref5(2,1), com_com_ref5(3,1), 'gx'); hold on;grid on;
% % 
% % 




% figure(2); grid on;
% 
% plot3(c_pos_agent1_x, c_pos_agent1_y, c_pos_agent1_z,'b-','LineWidth',1); hold on;grid on;
% plot3(c_pos_agent2_x, c_pos_agent2_y, c_pos_agent2_z,'r-','LineWidth',1); hold on;grid on;
% plot3(c_pos_agent3_x, c_pos_agent3_y, c_pos_agent3_z,'k-','LineWidth',1); hold on;grid on;
% plot3(c_pos_agent4_x, c_pos_agent4_y, c_pos_agent4_z,'c-','LineWidth',1); hold on;grid on;
% plot3(c_pos_agent5_x, c_pos_agent5_y, c_pos_agent5_z,'g-','LineWidth',1); hold on;grid on;
% %legend('p_1(t)', 'p_2(t)', 'p_3(t)', 'p_4(t)', 'p_5(t)'); hold on;
% 
% 
% plot3(ini_pos_1_x, ini_pos_1_y, ini_pos_1_z, 'bo'); hold on;grid on;
% plot3(ini_pos_2_x, ini_pos_2_y, ini_pos_2_z, 'ro'); hold on;grid on;
% plot3(ini_pos_3_x, ini_pos_3_y, ini_pos_3_z, 'ko'); hold on;grid on;
% plot3(ini_pos_4_x, ini_pos_4_y, ini_pos_4_z, 'co'); hold on;grid on;
% plot3(ini_pos_5_x, ini_pos_5_y, ini_pos_5_z, 'go'); hold on;grid on;
% %legend('p_1(t_0)', 'p_2(t_0)', 'p_3(t_0)', 'p_4(t_0)', 'p_5(t_0)'); hold on;
% 
% 
% 
% plot3(ref_pos_1_x, ref_pos_1_y, ref_pos_1_z, 'b>'); hold on;grid on;
% plot3(ref_pos_2_x, ref_pos_2_y, ref_pos_2_z, 'r>'); hold on;grid on;
% plot3(ref_pos_3_x, ref_pos_3_y, ref_pos_3_z, 'k>'); hold on;grid on;
% plot3(ref_pos_4_x, ref_pos_4_y, ref_pos_4_z, 'c>'); hold on;grid on;
% plot3(ref_pos_5_x, ref_pos_5_y, ref_pos_5_z, 'g>'); hold on;grid on;
% legend('p_1(t)', 'p_2(t)', 'p_3(t)', 'p_4(t)', 'p_5(t)', 'p_1(t_0)', 'p_2(t_0)', 'p_3(t_0)', 'p_4(t_0)', 'p_5(t_0)','p_1^\ast', 'p_2^\ast', 'p_3^\ast', 'p_4^\ast', 'p_5^\ast'); hold on;
% 



%plot3(pos(1,2,:), pos(2,2,:), pos(3,2,:),'ro-','LineWidth',2);
%plot3(pos(1,3,:), pos(2,3,:), pos(3,3,:),'ko-','LineWidth',2);
%plot3(pos(1,4,:), pos(2,4,:), pos(3,4,:),'co-','LineWidth',2);
%plot3(pos(1,5,:), pos(2,5,:), pos(3,5,:),'go-','LineWidth',2);



%plot(pos(1,:), pos(2,:),'b-','LineWidth',2);
%plot(pos(1,k+1), pos(2,k+1),'b>-','LineWidth',2);

%figure(1) ; hold on ; grid on;
%plot(pos(3,1), pos(4,1),'go-','LineWidth',2);
%plot(pos(3,:), pos(4,:),'g-','LineWidth',2);
%plot(pos(3,k+1), pos(4,k+1),'g>-','LineWidth',2);

%figure(1) ; hold on ; grid on;
%plot(pos(5,1), pos(6,1),'ro-','LineWidth',2);
%plot(pos(5,:), pos(6,:),'r-','LineWidth',2);
%plot(pos(5,k+1), pos(6,k+1),'r>-','LineWidth',2);




