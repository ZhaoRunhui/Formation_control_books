clear all

format long
% Coded by Hyo-Sung Ahn, 2018, 3-19
% Inputs %%

% Input 1: define nodes
node_id =['1', '2', '3', '4', '5'];  

% Input 2:  decide the number of edges
NumofEdges = 5; 

% Input 3-1: decide the edges for sensings
for i=1:1:NumofEdges
    for j= 1:1:NumofEdges
        s_edge(i,j)=0;
        c_edge(i,j)=0;
    end
end


s_edge(1,2)=1; s_edge(1,5)=1; %Edge(2,3)=1; Edge(1,5)=1; 
s_m1=2;

%Edge(2,1)=1; Edge(2,4)=1;
s_edge(2,1)=1; s_edge(2,3)=1; s_edge(2,4)=1;
s_m2=3;


s_edge(3,2)=1; s_edge(3,4)=1; s_edge(3,5)=1;
s_m3=3;


s_edge(4,2)=1; s_edge(4,3)=1; s_edge(4,5)=1;
s_m4=3;


%Edge(4,1)=1; %Edge(4,2)=0; Edge(4,5)=0;
%m4=2;

s_edge(5,3)=1; s_edge(5,4)=1 ; s_edge(5,1)=1 ;
s_m5=3;




% Input 3-2: decide the edges for communications/actuation
c_edge(1,2)=1; %s_edge(1,3)=1; %Edge(2,3)=1; Edge(1,5)=1; 
c_m1=1;

%Edge(2,1)=1; Edge(2,4)=1;
c_edge(2,3)=1; c_edge(2,4)=1; %s_edge(2,4)=1;
c_m2=2;


c_edge(3,4)=1; %c_edge(3,5)=1; %s_edge(3,5)=1;
c_m3=1;


c_edge(4,2)=1; c_edge(4,5)=1; %s_edge(4,5)=1;
c_m4=2;


%Edge(4,1)=1; %Edge(4,2)=0; Edge(4,5)=0;
%m4=2;

c_edge(5,4)=1; c_edge(5,1)=1 ; %Edge(5,4)=1 ;
c_m5=2;







% Input 4: default values for initial states/ reference positions
systemsize= size(node_id);
NumofNodes = systemsize(2) ;

% case 1 == very general 
%phi(1)=pi/2.4; 
%phi(2)=1.5*pi;
%phi(3)=-1.3*pi;
%phi(4)=pi/5;
%phi(5)=-pi/8;

% case 1
%   ini_theta(1)=pi/1.3;
%   ini_theta(2)=pi/3;
%   ini_theta(3)=pi/20;
%   ini_theta(4)=pi/2.1;
%   ini_theta(5)=1.9*pi;
 


% case 2
%  ini_theta(1)=pi/2;
%  ini_theta(2)=-2*pi;
%  ini_theta(3)=pi/10;
%  ini_theta(4)=-pi/1.2;
%  ini_theta(5)=-pi/2;
 

% case 3
 ini_theta(1)=pi/2.01;
 ini_theta(2)=-2*pi;
 ini_theta(3)=0.01*pi;
 ini_theta(4)=pi/1.2;
 ini_theta(5)=-pi/2.001; 
 
% 
% psi(1)=1.8*pi;
% psi(2)=-1.2*pi;
% psi(3)=1.2*pi;
% psi(4)=0.4*pi;
% psi(5)=-0.8*pi;




% phi(1)=pi/2.4; 
% phi(2)=phi(1) +0.01;
% phi(3)=phi(1) +0.02;
% phi(4)=phi(1) -0.01;
% phi(5)=phi(1) -0.02;
% 
% theta(1)=pi/1.9;
% theta(2)= theta(1)-0.02;
% theta(3)= theta(1)-0.01;
% theta(4)= theta(1)+0.02;
% theta(5)= theta(1)-0.015;
% 
% psi(1)=1.8*pi;
% psi(2)= psi(1) +0.02;
% psi(3)= psi(1) -0.02;
% psi(4)= psi(1) -0.01;
% psi(5)= psi(1) +0.003;


%  3 D
% ini_pos(:,1) = [0, 0, 0]';
% ini_pos(:,2) = [1, 3, 4]';
% ini_pos(:,3) = [6, 7, -10]';
% ini_pos(:,4) = [3, 0, -3]';
% ini_pos(:,5) = [-3, -2, 1]';
% 
% ref_pos(:,1) = [2, 3, 4]';
% ref_pos(:,2) = [-2.4, 3.7, 4.2]';
% ref_pos(:,3) = [2.2, -1.0, -3]';
% ref_pos(:,4) = [-0.5, 3.3, -3]';
% ref_pos(:,5) = [1.2, 1.3, -4.5]';

% 2 D
ini_pos(:,1) = [0, 0]';
ini_pos(:,2) = [1, 3]';
ini_pos(:,3) = [6, 7]';
ini_pos(:,4) = [3, 0]';
ini_pos(:,5) = [-3,-2]';

ref_pos(:,1) = [2, 3]';
ref_pos(:,2) = [-2.4, 3.7]';
ref_pos(:,3) = [2.2, -1.0]';
ref_pos(:,4) = [-0.5, 3.3]';
ref_pos(:,5) = [1.2, 1.3]';



time_index =1;
for i=1: NumofNodes
    %D_phi = [cos(phi(i)), -sin(phi(i)), 0; sin(phi(i)), cos(phi(i)), 0; 0, 0, 1]  ;
    %D_theta = [cos(theta(i)), 0, sin(theta(i)); 0, 1, 0; -sin(theta(i)),0,  cos(theta(i))];  
    %D_psi = [1, 0, 0; 0, cos(psi(i)), -sin(psi(i)); 0, sin(psi(i)), cos(psi(i))] ;
    % 2 D
    
    % Global --> Local
    D_theta = [cos(ini_theta(i)), -sin(ini_theta(i)); sin(ini_theta(i)), cos(ini_theta(i))];  % R_i^g    
    
    theta(i,time_index) = ini_theta(i);    
    R(:,:, i, time_index) = D_theta ; %  R_i^g  in R - 1st, 2nd --> rotation values; "i" --> agent index, 'time_index' --> sampling     
    pos(:,i,time_index) = ini_pos(:,i);    % 1st --> position, 2nd --> agent index, 'time index' --> sampling 
    %save_R(:,:,i, 1) = D_phi_theta_psi;
    %save_pos(:,i, 1) = ini_pos(:,i) ;
end


% for ii=1:NumofNodes
% %    for kk=1:2
%            rand_3_1 = rand(3,1);
%            rand_3_2 = rand(3,1);           
%            rand_inputs(:,:) = [rand_3_1/norm(rand_3_1), rand_3_2/norm(rand_3_2)]
%            z_hat(:,:, ii) = rand_inputs(:,:); %1st --> k=1, 2nd --> k=2; ii --> agent index
%  %   end
% end



%%%% Iteration loop starts %%%%

repeat_end = 10000;
dt = 0.001;
save_kk=0;

for time_index=1: 1: repeat_end % time index
% Agent updates
% 1. Update by sensings; R_{ji}^{-1}/ Omega_i
    for i=1: 1: NumofNodes
        for j=1:1: NumofNodes        
            if s_edge(j,i) ~= 1
                theta_ji(j, i) = 0 ;                
            else
                
              aaas = theta(j,time_index) - theta(i,time_index) + pi  ;        
              theta_ji_modulo =   mod(aaas,2*pi)  - pi ;
              theta_ji_cal =  theta_ji_modulo;              
              
              
              
              %if time_index ==1
              %  eig(R_ji_cal)
              %end
              
              %R_ji_inv_cal(:,:) = inv(R_ji_cal(:,:));
              theta_ji(j, i) = theta_ji_cal ; 
            end
        end
        
    % B_i
%     
%         v_i_1 = z_hat(:,1, i);
%         b_i_1 = v_i_1/norm(v_i_1);        
%         v_i_2 = z_hat(:,2, i) -     (z_hat(:,2, i)'*b_i_1) *b_i_1 ;
%         b_i_2 = v_i_2/norm(v_i_2);  
%         b_i_3 = cross(b_i_1, b_i_2);
%         B_i(:,1, i) = b_i_1;
%         B_i(:,2, i) = b_i_2;
%         B_i(:,3, i) = b_i_3; 
%         
%         BBB=[b_i_1, b_i_2, b_i_3];
%         %Omega_log = - log(BBB);
%         vtheta_i = acos( (trace(BBB) -1)/2 );
%         Omega_log = -vtheta_i/(2*sin(vtheta_i))*(BBB' - BBB);
%         Omega(:,1,i) = Omega_log(:,1);
%         Omega(:,2,i) = Omega_log(:,2);
%         Omega(:,3,i) = Omega_log(:,3);        
    end 
    
    
  
    % updates of auxiliary variables/ rotation matrix R_i/ Omega_i/ position of agent i 
    for i=1: 1: NumofNodes   
%         z_hat_k1_i_input_plus = 0;
%         z_hat_k2_i_input_plus = 0;
        theta_sum_plus = 0;
        u_global_i_plus = 0;
        
        %number_of_comm_neighbors = 0;
        nocn_i = 0;
%        z_hat_i_12(:,:) = z_hat(:,:, i) ;    
        aji =1;

        for j=1: 1: NumofNodes                           
               if c_edge(j,i) == 1  % j is the incoming neighbor node of agent i               
               nocn_i = nocn_i +1;
               % z_hat    
               %z_hat_j_12(:,:) = z_hat(:,:, j) ;
               
               theta_sum_plus = theta_sum_plus + theta_ji(j,i);               
               %z_hat_k2_i_input_plus = z_hat_k2_i_input_plus + aji*(R_ji_inv(:,:, j, i)* z_hat_j_12(:,2)  - z_hat_i_12(:,2) );               
               
               % u_global_i update theta(j,time_index)
               AAS =  R(:,:, i, time_index); % R(:,:, i, time_index) : g --> local
               R_i2g(:,:) = AAS(:,:)' ;
               %B_i_time(:,:) =  B_i(:,:, i);
               u_global_i_plus = u_global_i_plus  +  ( pos(:,j,time_index) - pos(:,i,time_index) )  -  R_i2g*( ref_pos(:,j) -   ref_pos(:,i) ) ;         
               end
        end
          
        if nocn_i ~=0  % if there is neighbor agents            
               %z_hat_dot_k1= z_hat_k1_i_input_plus - Omega(:,:,i)*z_hat_i_12(:,1);
               %z_hat_dot_k2= z_hat_k2_i_input_plus - Omega(:,:,i)*z_hat_i_12(:,2);
               
               % update of auxiliary variables 
               %z_hat_i_at_current(:,:) = z_hat(:,:, i) ;
               %z_hat_propagation_k1 = z_hat_i_at_current(:,1) + z_hat_dot_k1*dt;
               %z_hat_propagation_k2 = z_hat_i_at_current(:,2) + z_hat_dot_k2*dt;               
               
               %z_hat(:,1, i) = z_hat_propagation_k1(:) ;
               %z_hat(:,2, i) = z_hat_propagation_k2(:) ;               
               
               % update of rotation matrices                
               theta_dot(i) = theta_sum_plus ;  
               pos_dot(:,i) = u_global_i_plus ;              
               
               
               theta(i, time_index+1) = theta(i,time_index) +theta_dot(i)*dt;   
               
               % update of positions
               pos(:,i,time_index+1) =  pos(:,i,time_index)  + pos_dot(:,i)*dt;                            
               
        else
               theta(i, time_index+1) = theta(i,time_index) ;   
               
               % update of positions
               pos(:,i,time_index+1) =  pos(:,i,time_index)  ;                            
        
        end           
        
        
         
         D_theta = [cos(theta(i, time_index+1) ), sin(theta(i, time_index+1)); -sin(theta(i, time_index+1)), cos(theta(i, time_index+1))];  % R_i^g          
         R(:,:, i, time_index+1) = D_theta ; 
        
        
        save_index = mod(time_index, 25);    

        if  save_index ==1
            save_kk = save_kk+1;
            for i=1:1:NumofNodes
             save_theta(i, save_kk) = theta(i, time_index);
%             tation_i(:,:) = save_R(:,:,i, save_kk);
             %save_r_i = rotm2eul(Rotation_i);
             %save_euler(:,i,save_kk) = save_Euler_i(:);
             save_pos(:,i, save_kk) = pos(:, i, time_index);    
             
             % compensation the rotation;             
             %c_save_pos(:,i, save_kk) =inv(R(:,:, i, time_index))*pos(:, i, time_index);  
             
            end
        end   

    end
end


% R(:,:, 1, time_index) 
% R(:,:, 2, time_index)
% R(:,:, 3, time_index) 
% R(:,:, 4, time_index)
% R(:,:, 5, time_index) 


  
  

%figure(1) ; hold on ; grid on;
ini_pos_1_x = ini_pos(1,1);
ini_pos_1_y = ini_pos(2,1);
%ini_pos_1_z = ini_pos(3,1);
ini_pos_2_x = ini_pos(1,2);
ini_pos_2_y = ini_pos(2,2);
%ini_pos_2_z = ini_pos(3,2);
ini_pos_3_x = ini_pos(1,3);
ini_pos_3_y = ini_pos(2,3);
%ini_pos_3_z = ini_pos(3,3);
ini_pos_4_x = ini_pos(1,4);
ini_pos_4_y = ini_pos(2,4);
%ini_pos_4_z = ini_pos(3,4);
ini_pos_5_x = ini_pos(1,5);
ini_pos_5_y = ini_pos(2,5);
%ini_pos_5_z = ini_pos(3,5);


%ref_pos(:,1)
ref_pos_1_x = ref_pos(1,1);
ref_pos_1_y = ref_pos(2,1);
%ref_pos_1_z = ref_pos(3,1);
ref_pos_2_x = ref_pos(1,2);
ref_pos_2_y = ref_pos(2,2);
%ref_pos_2_z = ref_pos(3,2);
ref_pos_3_x = ref_pos(1,3);
ref_pos_3_y = ref_pos(2,3);
%ref_pos_3_z = ref_pos(3,3);
ref_pos_4_x = ref_pos(1,4);
ref_pos_4_y = ref_pos(2,4);
%ref_pos_4_z = ref_pos(3,4);
ref_pos_5_x = ref_pos(1,5);
ref_pos_5_y = ref_pos(2,5);
%ref_pos_5_z = ref_pos(3,5);

pos_agent1_x(:) = save_pos(1,1,:);
pos_agent1_y(:) = save_pos(2,1,:);
%pos_agent1_z(:) = save_pos(3,1,:);

pos_agent2_x(:) = save_pos(1,2,:);
pos_agent2_y(:) = save_pos(2,2,:);
%pos_agent2_z(:) = save_pos(3,2,:);

pos_agent3_x(:) = save_pos(1,3,:);
pos_agent3_y(:) = save_pos(2,3,:);
%pos_agent3_z(:) = save_pos(3,3,:);

pos_agent4_x(:) = save_pos(1,4,:);
pos_agent4_y(:) = save_pos(2,4,:);
%pos_agent4_z(:) = save_pos(3,4,:);

pos_agent5_x(:) = save_pos(1,5,:);
pos_agent5_y(:) = save_pos(2,5,:);
%pos_agent5_z(:) = save_pos(3,5,:);





% c_pos_agent1_x(:) = c_save_pos(1,1,:);
% c_pos_agent1_y(:) = c_save_pos(2,1,:);
% c_pos_agent1_z(:) = c_save_pos(3,1,:);
% 
% c_pos_agent2_x(:) = c_save_pos(1,2,:);
% c_pos_agent2_y(:) = c_save_pos(2,2,:);
% c_pos_agent2_z(:) = c_save_pos(3,2,:);
% 
% c_pos_agent3_x(:) = c_save_pos(1,3,:);
% c_pos_agent3_y(:) = c_save_pos(2,3,:);
% c_pos_agent3_z(:) = c_save_pos(3,3,:);
% 
% c_pos_agent4_x(:) = c_save_pos(1,4,:);
% c_pos_agent4_y(:) = c_save_pos(2,4,:);
% c_pos_agent4_z(:) = c_save_pos(3,4,:);
% 
% c_pos_agent5_x(:) = c_save_pos(1,5,:);
% c_pos_agent5_y(:) = c_save_pos(2,5,:);
% c_pos_agent5_z(:) = c_save_pos(3,5,:);
% 


figure(1); grid on;

plot(pos_agent1_x, pos_agent1_y, 'b-','LineWidth',1); hold on;grid on;
plot(pos_agent2_x, pos_agent2_y, 'r-','LineWidth',1); hold on;grid on;
plot(pos_agent3_x, pos_agent3_y, 'k-','LineWidth',1); hold on;grid on;
plot(pos_agent4_x, pos_agent4_y, 'c-','LineWidth',1); hold on;grid on;
plot(pos_agent5_x, pos_agent5_y, 'g-','LineWidth',1); hold on;grid on;
%legend('p_1(t)', 'p_2(t)', 'p_3(t)', 'p_4(t)', 'p_5(t)'); hold on;


plot(ini_pos_1_x, ini_pos_1_y, 'bo'); hold on;grid on;
plot(ini_pos_2_x, ini_pos_2_y, 'ro'); hold on;grid on;
plot(ini_pos_3_x, ini_pos_3_y, 'ko'); hold on;grid on;
plot(ini_pos_4_x, ini_pos_4_y, 'co'); hold on;grid on;
plot(ini_pos_5_x, ini_pos_5_y, 'go'); hold on;grid on;
%legend('p_1(t_0)', 'p_2(t_0)', 'p_3(t_0)', 'p_4(t_0)', 'p_5(t_0)'); hold on;



plot(ref_pos_1_x, ref_pos_1_y, 'b>'); hold on;grid on;
plot(ref_pos_2_x, ref_pos_2_y, 'r>'); hold on;grid on;
plot(ref_pos_3_x, ref_pos_3_y, 'k>'); hold on;grid on;
plot(ref_pos_4_x, ref_pos_4_y, 'c>'); hold on;grid on;
plot(ref_pos_5_x, ref_pos_5_y, 'g>'); hold on;grid on;
%legend('p_1(t)', 'p_2(t)', 'p_3(t)', 'p_4(t)', 'p_5(t)', 'p_1(t_0)', 'p_2(t_0)', 'p_3(t_0)', 'p_4(t_0)', 'p_5(t_0)','p_1^\ast', 'p_2^\ast', 'p_3^\ast', 'p_4^\ast', 'p_5^\ast'); hold on;
%title('Before the offset compensation')
xlabel('x-axis');
ylabel('y-axis');
%zlabel('z-axis');

%%%%%%%%%% compensation %%%%%%%%%%%

agent1_final(:,1) = save_pos(:,1,save_kk);
agent2_final(:,1) = save_pos(:,2,save_kk);
agent3_final(:,1) = save_pos(:,3,save_kk);
agent4_final(:,1) = save_pos(:,4,save_kk);
agent5_final(:,1) = save_pos(:,5,save_kk);




save_theta(i, save_kk)

for i=1:1:NumofNodes
  DDDD  = [cos( save_theta(i, save_kk) ), sin( save_theta(i, save_kk) ); -sin( save_theta(i, save_kk) ), cos( save_theta(i, save_kk) )];  % R_i^g        
  D_theta_final(:,:,i) = DDDD(:,:)' ;
end



com_ref1(:,1) = D_theta_final(:,:,1)*ref_pos(:,1) ;
com_ref2(:,1) = D_theta_final(:,:,2)*ref_pos(:,2) ;
com_ref3(:,1) = D_theta_final(:,:,3)*ref_pos(:,3) ;
com_ref4(:,1) = D_theta_final(:,:,4)*ref_pos(:,4) ;
com_ref5(:,1) = D_theta_final(:,:,5)*ref_pos(:,5) ;

position_offset = agent1_final(:,1) - com_ref1(:,1);

com_com_ref1(:,1) = com_ref1(:,1) +position_offset;
com_com_ref2(:,1) = com_ref2(:,1) +position_offset;
com_com_ref3(:,1) = com_ref3(:,1) +position_offset;
com_com_ref4(:,1) = com_ref4(:,1) +position_offset;
com_com_ref5(:,1) = com_ref5(:,1) +position_offset;



%     agent2_final(:,1) - agent4_final(:,1)
%     agent1_final(:,1) - agent5_final(:,1)
%     
%     com_ref2(:,1) - com_ref4(:,1)
%     com_ref1(:,1) - com_ref5(:,1)  





figure(2); grid on;

plot(pos_agent1_x, pos_agent1_y, 'b-','LineWidth',1); hold on;grid on;
plot(pos_agent2_x, pos_agent2_y, 'r-','LineWidth',1); hold on;grid on;
plot(pos_agent3_x, pos_agent3_y, 'k-','LineWidth',1); hold on;grid on;
plot(pos_agent4_x, pos_agent4_y, 'c-','LineWidth',1); hold on;grid on;
plot(pos_agent5_x, pos_agent5_y, 'g-','LineWidth',1); hold on;grid on;
%legend('p_1(t)', 'p_2(t)', 'p_3(t)', 'p_4(t)', 'p_5(t)'); hold on;


plot(ini_pos_1_x, ini_pos_1_y, 'bo'); hold on;grid on;
plot(ini_pos_2_x, ini_pos_2_y, 'ro'); hold on;grid on;
plot(ini_pos_3_x, ini_pos_3_y,  'ko'); hold on;grid on;
plot(ini_pos_4_x, ini_pos_4_y,  'co'); hold on;grid on;
plot(ini_pos_5_x, ini_pos_5_y,  'go'); hold on;grid on;
%legend('p_1(t_0)', 'p_2(t_0)', 'p_3(t_0)', 'p_4(t_0)', 'p_5(t_0)'); hold on;



plot(com_com_ref1(1,1), com_com_ref1(2,1),  'b>'); hold on;grid on;
plot(com_com_ref2(1,1), com_com_ref2(2,1),  'r>'); hold on;grid on;
plot(com_com_ref3(1,1), com_com_ref3(2,1),  'k>'); hold on;grid on;
plot(com_com_ref4(1,1), com_com_ref4(2,1),  'c>'); hold on;grid on;
plot(com_com_ref5(1,1), com_com_ref5(2,1),  'g>'); hold on;grid on;
%legend('p_1(t)', 'p_2(t)', 'p_3(t)', 'p_4(t)', 'p_5(t)', 'p_1(t_0)', 'p_2(t_0)', 'p_3(t_0)', 'p_4(t_0)', 'p_5(t_0)','p_1^\ast', 'p_2^\ast', 'p_3^\ast', 'p_4^\ast', 'p_5^\ast'); hold on;
%title('After the offset compensation')
xlabel('x-axis');
ylabel('y-axis');
%zlabel('z-axis');

% Euler angles

euler_agent1_x(:) = save_theta(1,:);
euler_agent2_x(:) = save_theta(2,:);
euler_agent3_x(:) = save_theta(3,:);
euler_agent4_x(:) = save_theta(4,:);
euler_agent5_x(:) = save_theta(5,:);

% 
% euler_agent1_y(:) = save_euler(2,1,:);
% euler_agent1_z(:) = save_euler(3,1,:);
% 
% euler_agent2_x(:) = save_euler(1,2,:);
% euler_agent2_y(:) = save_euler(2,2,:);
% euler_agent2_z(:) = save_euler(3,2,:);
% 
% euler_agent3_x(:) = save_euler(1,3,:);
% euler_agent3_y(:) = save_euler(2,3,:);
% euler_agent3_z(:) = save_euler(3,3,:);
% 
% euler_agent4_x(:) = save_euler(1,4,:);
% euler_agent4_y(:) = save_euler(2,4,:);
% euler_agent4_z(:) = save_euler(3,4,:);
% 
% euler_agent5_x(:) = save_euler(1,5,:);
% euler_agent5_y(:) = save_euler(2,5,:);
% euler_agent5_z(:) = save_euler(3,5,:);



figure(3)


%save_theta(i, save_kk)

plot(euler_agent1_x,'b-','LineWidth',1); hold on;grid on;
plot(euler_agent2_x,'r-','LineWidth',1); hold on;grid on;
plot(euler_agent3_x,'k-','LineWidth',1); hold on;grid on;
plot(euler_agent4_x,'c-','LineWidth',1); hold on;grid on;
plot(euler_agent5_x,'g-','LineWidth',1); hold on;grid on;

% plot3(euler_agent1_x(1), euler_agent1_y(1), euler_agent1_z(1), 'bo'); hold on;grid on;
% plot3(euler_agent2_x(1), euler_agent2_y(1), euler_agent2_z(1), 'ro'); hold on;grid on;
% plot3(euler_agent3_x(1), euler_agent3_y(1), euler_agent3_z(1), 'ko'); hold on;grid on;
% plot3(euler_agent4_x(1), euler_agent4_y(1), euler_agent4_z(1), 'co'); hold on;grid on;
% plot3(euler_agent5_x(1), euler_agent5_y(1), euler_agent5_z(1), 'go'); hold on;grid on;
% 
% plot3(euler_agent1_x(save_kk), euler_agent1_y(save_kk), euler_agent1_z(save_kk), 'b>'); hold on;grid on;
% plot3(euler_agent2_x(save_kk), euler_agent2_y(save_kk), euler_agent2_z(save_kk), 'r>'); hold on;grid on;
% plot3(euler_agent3_x(save_kk), euler_agent3_y(save_kk), euler_agent3_z(save_kk), 'k>'); hold on;grid on;
% plot3(euler_agent4_x(save_kk), euler_agent4_y(save_kk), euler_agent4_z(save_kk), 'c>'); hold on;grid on;
% plot3(euler_agent5_x(save_kk), euler_agent5_y(save_kk), euler_agent5_z(save_kk), 'g>'); hold on;grid on;
%title('Orientation alignment (trajectories of Euler angles)')
ylabel('\theta(t)');
%ylabel('\theta(t)');
%zlabel('\psi(t)');
%legend('p_1(t_0)', 'p_2(t_0)', 'p_3(t_0)', 'p_4(t_0)', 'p_5(t_0)'); hold on;





% 
%     
% 
% figure(2); grid on;
% plot3(agent1_final(1,1), agent1_final(2,1), agent1_final(3,1), 'b>'); hold on;grid on;
% plot3(agent2_final(1,1), agent2_final(2,1), agent2_final(3,1), 'r>'); hold on;grid on;
% plot3(agent3_final(1,1), agent3_final(2,1), agent3_final(3,1), 'k>'); hold on;grid on;
% plot3(agent4_final(1,1), agent4_final(2,1), agent4_final(3,1), 'c>'); hold on;grid on;
% plot3(agent5_final(1,1), agent5_final(2,1), agent5_final(3,1), 'g>'); hold on;grid on;
% 
% plot3(com_ref1(1,1), com_ref1(2,1), com_ref1(3,1), 'bo'); hold on;grid on;
% plot3(com_ref2(1,1), com_ref2(2,1), com_ref2(3,1), 'ro'); hold on;grid on;
% plot3(com_ref3(1,1), com_ref3(2,1), com_ref3(3,1), 'ko'); hold on;grid on;
% plot3(com_ref4(1,1), com_ref4(2,1), com_ref4(3,1), 'co'); hold on;grid on;
% plot3(com_ref5(1,1), com_ref5(2,1), com_ref5(3,1), 'go'); hold on;grid on;
% 
% plot3(com_com_ref1(1,1), com_com_ref1(2,1), com_com_ref1(3,1), 'bx'); hold on;grid on;
% plot3(com_com_ref2(1,1), com_com_ref2(2,1), com_com_ref2(3,1), 'rx'); hold on;grid on;
% plot3(com_com_ref3(1,1), com_com_ref3(2,1), com_com_ref3(3,1), 'kx'); hold on;grid on;
% plot3(com_com_ref4(1,1), com_com_ref4(2,1), com_com_ref4(3,1), 'cx'); hold on;grid on;
% plot3(com_com_ref5(1,1), com_com_ref5(2,1), com_com_ref5(3,1), 'gx'); hold on;grid on;
% % 
% % 




% figure(2); grid on;
% 
% plot3(c_pos_agent1_x, c_pos_agent1_y, c_pos_agent1_z,'b-','LineWidth',1); hold on;grid on;
% plot3(c_pos_agent2_x, c_pos_agent2_y, c_pos_agent2_z,'r-','LineWidth',1); hold on;grid on;
% plot3(c_pos_agent3_x, c_pos_agent3_y, c_pos_agent3_z,'k-','LineWidth',1); hold on;grid on;
% plot3(c_pos_agent4_x, c_pos_agent4_y, c_pos_agent4_z,'c-','LineWidth',1); hold on;grid on;
% plot3(c_pos_agent5_x, c_pos_agent5_y, c_pos_agent5_z,'g-','LineWidth',1); hold on;grid on;
% %legend('p_1(t)', 'p_2(t)', 'p_3(t)', 'p_4(t)', 'p_5(t)'); hold on;
% 
% 
% plot3(ini_pos_1_x, ini_pos_1_y, ini_pos_1_z, 'bo'); hold on;grid on;
% plot3(ini_pos_2_x, ini_pos_2_y, ini_pos_2_z, 'ro'); hold on;grid on;
% plot3(ini_pos_3_x, ini_pos_3_y, ini_pos_3_z, 'ko'); hold on;grid on;
% plot3(ini_pos_4_x, ini_pos_4_y, ini_pos_4_z, 'co'); hold on;grid on;
% plot3(ini_pos_5_x, ini_pos_5_y, ini_pos_5_z, 'go'); hold on;grid on;
% %legend('p_1(t_0)', 'p_2(t_0)', 'p_3(t_0)', 'p_4(t_0)', 'p_5(t_0)'); hold on;
% 
% 
% 
% plot3(ref_pos_1_x, ref_pos_1_y, ref_pos_1_z, 'b>'); hold on;grid on;
% plot3(ref_pos_2_x, ref_pos_2_y, ref_pos_2_z, 'r>'); hold on;grid on;
% plot3(ref_pos_3_x, ref_pos_3_y, ref_pos_3_z, 'k>'); hold on;grid on;
% plot3(ref_pos_4_x, ref_pos_4_y, ref_pos_4_z, 'c>'); hold on;grid on;
% plot3(ref_pos_5_x, ref_pos_5_y, ref_pos_5_z, 'g>'); hold on;grid on;
% legend('p_1(t)', 'p_2(t)', 'p_3(t)', 'p_4(t)', 'p_5(t)', 'p_1(t_0)', 'p_2(t_0)', 'p_3(t_0)', 'p_4(t_0)', 'p_5(t_0)','p_1^\ast', 'p_2^\ast', 'p_3^\ast', 'p_4^\ast', 'p_5^\ast'); hold on;
% 



%plot3(pos(1,2,:), pos(2,2,:), pos(3,2,:),'ro-','LineWidth',2);
%plot3(pos(1,3,:), pos(2,3,:), pos(3,3,:),'ko-','LineWidth',2);
%plot3(pos(1,4,:), pos(2,4,:), pos(3,4,:),'co-','LineWidth',2);
%plot3(pos(1,5,:), pos(2,5,:), pos(3,5,:),'go-','LineWidth',2);



%plot(pos(1,:), pos(2,:),'b-','LineWidth',2);
%plot(pos(1,k+1), pos(2,k+1),'b>-','LineWidth',2);

%figure(1) ; hold on ; grid on;
%plot(pos(3,1), pos(4,1),'go-','LineWidth',2);
%plot(pos(3,:), pos(4,:),'g-','LineWidth',2);
%plot(pos(3,k+1), pos(4,k+1),'g>-','LineWidth',2);

%figure(1) ; hold on ; grid on;
%plot(pos(5,1), pos(6,1),'ro-','LineWidth',2);
%plot(pos(5,:), pos(6,:),'r-','LineWidth',2);
%plot(pos(5,k+1), pos(6,k+1),'r>-','LineWidth',2);




